/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.x15015556.ca2_resit;

import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author x15015556
 */
@Path("/students")
@Singleton
public class StudentService {

    private final ArrayList<Student> students;
    private final ArrayList<Subject> subjects;

    public StudentService() {

        students = new ArrayList<>();
        students.add(new Student(1, "John", "Smith"));
        students.add(new Student(2, "Mary", "Simmons"));
        students.add(new Student(3, "Bob", "Hope"));
        students.add(new Student(4, "Sam", "Jones"));
        students.add(new Student(5, "Fiona", "Wallaby"));

        subjects = new ArrayList<>();
        subjects.add(new Subject(20, "Web Services and API", "web desc"));
        subjects.add(new Subject(21, "Intro to Artificial Intelligence", "ai desc"));
        subjects.add(new Subject(22, "Data Application Development", "data desc"));
        subjects.add(new Subject(23, "Software Project", "software desc"));

        students.get(1).addSubject(subjects.get(20));
        students.get(1).addSubject(subjects.get(21));
        students.get(3).addSubject(subjects.get(22));
        students.get(5).addSubject(subjects.get(23));

    }

    // curl "http://localhost:8080/api/students"
    // @ref Moodle: ProgrammingTestSolution
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudents() {
        Gson gson = new Gson();
        return Response.status(Response.Status.OK).entity(gson.toJson(students)).build();
    }

    // curl "http://localhost:8080/api/students/0"
    // @ref: Moodle - ProgrammingTestSolution
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudent(@PathParam("id") int id) {
        if (id < 0 || id >= students.size()) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        Student target = students.get(id);
        Gson gson = new Gson();
        String jsonRepresentation = gson.toJson(target);
        return Response.status(Response.Status.OK).entity(jsonRepresentation).build();
    }

    // curl "http://localhost:8080/api/students/v2?startId=1&offset=3"
    //@ref Moodle: ProgrammingTestSolution
    @GET
    @Path("/v2/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudentsV2(@Context UriInfo info) {

        int start = Integer.parseInt(info.getQueryParameters().getFirst("startId"));
        int offset = Integer.parseInt(info.getQueryParameters().getFirst("offset"));
        if (start < 0 || offset < 0) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        int off = start + offset;
        if (off > students.size()) {
            off = students.size();
        }

        List<Student> filtered = students.subList(start, off);

        Gson gson = new Gson();
        return Response.status(Response.Status.OK).entity(gson.toJson(filtered)).build();
    }

    // curl "http://localhost:8080/api/students/1/John"
    @GET
    @Path("{student_id}/{search_term)")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getSearch(@PathParam("student_id") int student_id) {

        Student target = null;

        List<Student> students = getAllStudents(student_id, "", "");
        String names = "";
        for (Student student : students) {
            names += student.getFirst_name() + " ";
        }
        Gson gson = new Gson();
        Map<String, String> map = new HashMap<>();
        map.put("info", gson.toJson(target));
        map.put("Student List", names);
        return Response.status(Response.Status.OK).entity(gson.toJson(map)).build();
    }
    
    // curl "http://localhost:8080/api/students/1/update"
    @GET
    @Path("{student_id}/update")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUpdate(@Context UriInfo info) {

        List<Student> students = new ArrayList<>();
        int student_id = Integer.parseInt(info.getQueryParameters().getFirst("first_name"));
        String first_name = info.getQueryParameters().getFirst("first_name");
        String last_name = info.getQueryParameters().getFirst("last_name");
        
        //@ref: https://www.baeldung.com/find-list-element-java
        for (Student student : students) {
            if (student.getStudent_id() == (student_id)) 
            student.setFirst_name(first_name);
            student.setLast_name(last_name);
        }
        Gson gson = new Gson();
        
        String message = "Record updated";
        
        return Response.status(Response.Status.OK).entity(message).build();
    }
    
    //@ref Moodle: ProgrammingTestSolution
    private List<Student> getAllStudents(int identifier, String first_name, String last_name) {
        List<Student> filteredStudents = new ArrayList<>();

        System.out.println(students);
        
        
        
        //@ref: https://www.baeldung.com/find-list-element-java
        for (Student student : students) {
            if (student.getFirst_name().equals(first_name)) {
                filteredStudents.add(student);
            }
        }
        
        //@ref: https://www.baeldung.com/find-list-element-java
        for (Student s1 : students) {
            if (s1.getLast_name().equals(last_name)) {
                filteredStudents.add(s1);
            }
        }
        
        //@ref: https://www.baeldung.com/find-list-element-java
        for (Student s2 : students) {
            if (s2.getFirst_name().equals(first_name) && s2.getLast_name().equals(last_name) ) {
                filteredStudents.add(s2);
            }
        }

        return filteredStudents;
    }
}

