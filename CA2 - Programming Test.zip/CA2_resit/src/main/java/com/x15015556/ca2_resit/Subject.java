/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.x15015556.ca2_resit;

/**
 *
 * @author x15015556
 */
public class Subject {
    private int subject_id;
    private String subject_title;
    private String subject_desc;

    public Subject() {
    }

    public Subject(int subject_id, String subject_title, String subject_desc) {
        this.subject_id = subject_id;
        this.subject_title = subject_title;
        this.subject_desc = subject_desc;
    }

    public int getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(int subject_id) {
        this.subject_id = subject_id;
    }

    public String getSubject_title() {
        return subject_title;
    }

    public void setSubject_title(String subject_title) {
        this.subject_title = subject_title;
    }

    public String getSubject_desc() {
        return subject_desc;
    }

    public void setSubject_desc(String subject_desc) {
        this.subject_desc = subject_desc;
    }

    @Override
    public String toString() {
        return "Subject{" + "subject_id=" + subject_id + ", subject_title=" + subject_title + ", subject_desc=" + subject_desc + '}';
    }
    
    
}
