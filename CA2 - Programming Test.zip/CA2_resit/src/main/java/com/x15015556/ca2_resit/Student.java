package com.x15015556.ca2_resit;

import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author x15015556
 */
public class Student {
    
    private int student_id;
    private String first_name;
    private String last_name;
    private List<Subject> subjects;

    public Student() {
    }

    public Student(int student_id, String first_name, String last_name) {
        this.student_id = student_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.subjects = new ArrayList<Subject>();
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }
    
    public void addSubject(Subject subject){
        
        this.subjects.add(subject);
    }

    @Override
    public String toString() {
        return "Student{" + "student_id=" + student_id + ", first_name=" + first_name + ", last_name=" + last_name + ", subjects=" + subjects + '}';
    }
    
    
}

