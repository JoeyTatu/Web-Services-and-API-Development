/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inttoromannumberals;

/**
 * @file: IntToRomanNumberals/java
 * @author x15015556
 */
import java.util.Scanner;

// This was me just testing the conversion. The Web Application is in the RomanNumConversionJSON project
public class IntToRomanNumberals {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the number between 1 and 2999:");
        int number = s.nextInt();
        String output = convertToRoman(number);
        
        System.out.println(output);
        
    }
    
    
    public static String convertToRoman(int number){
        if ((number < 1 || (number > 4999))){
            return "";
        }   
        if (number >= 1000){
            return "M" + convertToRoman(number - 1000);
        }
        if (number >= 900){
            return "CM" + convertToRoman(number - 900);
        } 
        if (number >= 500){
            return "D" + convertToRoman(number - 500);
        }
        if (number >= 400){
            return "CD" + convertToRoman(number - 400);
        }
        if (number >= 100){
            return "C" + convertToRoman(number - 100);
        }            
        if (number >= 90){
            return "XC" + convertToRoman(number - 90);
        }
        if (number >= 50){
            return "L" + convertToRoman(number - 50);
        }
        if (number >= 40){
            return "XL" + convertToRoman(number - 40);
        }
        if (number >= 10){
            return "X" + convertToRoman(number - 10);
        }
        if (number >= 9){
            return "IX" + convertToRoman(number - 9);
        }
        if (number >= 5){
            return "V" + convertToRoman(number - 5);
        }
        if (number >= 4){
            return "IV" + convertToRoman(number - 4);
        }
        if (number >= 1){
            return "I" + convertToRoman(number - 1);
        }
        return "";
    }

//        while((input >= 1000) && (input < 10000))
//            if((input - 1000) > 0){
//                output = output + "M";
//                input = input - 1000;
//            }
//        
//        while ((input < 1000) && (input >= 500)){
//            if((input - 500) > 0){
//                output = output + "D";
//                input = input - 500;
//            }
//        }
//        
//        while ((input >= 400) && (input <= 800)){
//            if((input - 400) > 0){
//                output = output + "CD";
//                input = input - 400;
//            }
//        }
//        
//        while ((input >= 100) && (input <= 399)){
//            if((input - 100) > 0){
//                output = output + "C";
//                input = input - 100;
//            }
//        }
//        
//        while ((input >= 90) && (input <= 99)){
//            if((input - 90) >0){
//                output = output + "XC";
//                input = input - 90;
//            }
//        }
//        
//        while((input >= 50) && (input <= 89)){
//            if((input - 50) > 0){
//                output = output + "L";
//                input = input - 50;
//            }
//        }
//        
//        while ((input >= 40) && (input <= 49)){
//            if((input - 40) > 0){
//                output = output + "XL";
//                input = input - 40;
//            }
//        }
//        
//        while ((input >= 10) && (input <= 39)){
//            if((input - 10) > 0){
//                output = output + "X";
//                input = input - 10;
//            }
//        }
//        
//        while ((input >= 9) && (input < 10)){
//            if((input - 9) > 0){
//                output = output + "IX";
//                input = input - 10;
//            }
//        }
//        
//        while ((input >= 5) && (input < 6)){
//            if((input - 5) > 0){
//                output = output + "V";
//                input = input - 5;
//            }
//        }
//        
//        while ((input >= 1) && (input < 10) && (!(input == 5))){
//            if((input - 1) > 0){
//                output = output + "I";
//                input = input - 1;
//            }
    
}
