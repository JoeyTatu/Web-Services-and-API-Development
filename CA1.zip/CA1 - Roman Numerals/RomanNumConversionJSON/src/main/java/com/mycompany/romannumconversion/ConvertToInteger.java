/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.romannumconversion;

/**
 * @file: ConvertToInteger.java
 * @created: 17 October 2018
 * @modified: 19 October 2019
 * @author: Keith Feeney - x15015556@student.ncirl.ie
 */
public class ConvertToInteger {
    
    String toIntegerInput;
    int toIntegerOutput;
    
        public ConvertToInteger(String toIntegerInput){
        toIntegerOutput = convert(toIntegerInput);
    }
    
    // @reference: https://stackoverflow.com/questions/9073150/converting-roman-numerals-to-decimal/9073310
    // @editedby: Keith Feeney
    public static int convertToInteger(String roman){ //converting roman numeral to integer
        
        //This sets the number and removes that corresponding letter from the int number,
        //e.g. for MMXVIII (2018), this 'if' is called first:
        //
        //if (roman.startsWith("M")){
        //    return 1000 + convertToInteger(roman.substring(1));
        //}
        //
        // It adds "1000" and removed "1000" from the String roman,
        // so now the returned int = 1000 and roman = "MXVIII". Then it sends it back through the method until there is no more letters.
        
        if (roman.isEmpty()){ //if string is empty, return 0
            return 0;
        }
        if (roman.startsWith("M")){
            return 1000 + convertToInteger(roman.substring(1));
        }
        else if (roman.startsWith("CM")){
            return 900 + convertToInteger(roman.substring(2));
        }
        else if (roman.startsWith("D")){
            return 500 + convertToInteger(roman.substring(1));
        }
        else if (roman.startsWith("CD")){
            return 400 + convertToInteger(roman.substring(2));
        }
        else if (roman.startsWith("C")){
            return 100 + convertToInteger(roman.substring(1));
        }
        else if (roman.startsWith("XC")){
            return 90 + convertToInteger(roman.substring(2));
        }
        else if (roman.startsWith("L")){
            return 50 + convertToInteger(roman.substring(1));
        }
        else if (roman.startsWith("XL")){
            return 40 + convertToInteger(roman.substring(2));
        }
        else if (roman.startsWith("X")){
            return 10 + convertToInteger(roman.substring(1));
        }
        else if (roman.startsWith("IX")){
            return 9 + convertToInteger(roman.substring(2));
        }
        else if (roman.startsWith("V")){
            return 5 + convertToInteger(roman.substring(1));
        }
        else if (roman.startsWith("IV")){
            return 4 + convertToInteger(roman.substring(2));
        }
        else if (roman.startsWith("I")){
            return 1 + convertToInteger(roman.substring(1));
        }
        throw new IllegalArgumentException("Error!"); //if a letter is not listed, throws an error.
    }
    // @reference: https://stackoverflow.com/questions/9073150/converting-roman-numerals-to-decimal/9073310
    // @editedby: Keith Feeney
    public static int convert(String roman) {
        if (roman == null || roman.isEmpty() || !roman.matches("^(M{0,3})(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$")){
        //if result is null, blank, or not a used Roman numeral, and 4 digits long (0-3), it will return -1 
            return -1;
        }    
        return convertToInteger(roman);
    }
}
