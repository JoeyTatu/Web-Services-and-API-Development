/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.romannumconversion;

/**
 * @file: ConvertToRoman.java
 * @created: 17 October 2018
 * @modified: 19 October 2019
 * @author: Keith Feeney - x15015556@student.ncirl.ie
 */
public class ConvertToRoman {
    
    //int toRomanInput;
    String toRomanOutput;
    
    public ConvertToRoman(int toRomanInput){
        toRomanOutput = convertToRoman(toRomanInput);
    }
    
    // @reference: https://stackoverflow.com/questions/12967896/converting-integers-to-roman-numerals-java
    // @editedby: Keith Feeney
    public static String convertToRoman(int number){ //convert integer to roman numeral
        
        //This sets the letter and removes that amount from the int number,
        //e.g. for 2018, this 'if' is called first:
        //
        //if (number >= 1000){
        //    return "M" + convertToRoman(number - 1000);
        //}
        //
        // It adds "M" to the String 'roman' and deducts 1000 from the int 2018,
        // so now number = 1018 and roman = "M". Then it sends it back through the method until it can't go further.
        
        if ((number < 1 || (number > 4999))){ //4999 is used, becasue 5000 (V with a line over it) cannot be written in standard Latin characters
        }   
        if (number >= 1000){
            return "M" + convertToRoman(number - 1000);
        }
        if (number >= 900){
            return "CM" + convertToRoman(number - 900);
        } 
        if (number >= 500){
            return "D" + convertToRoman(number - 500);
        }
        if (number >= 400){
            return "CD" + convertToRoman(number - 400);
        }
        if (number >= 100){
            return "C" + convertToRoman(number - 100);
        }            
        if (number >= 90){
            return "XC" + convertToRoman(number - 90);
        }
        if (number >= 50){
            return "L" + convertToRoman(number - 50);
        }
        if (number >= 40){
            return "XL" + convertToRoman(number - 40);
        }
        if (number >= 10){
            return "X" + convertToRoman(number - 10);
        }
        if (number >= 9){
            return "IX" + convertToRoman(number - 9);
        }
        if (number >= 5){
            return "V" + convertToRoman(number - 5);
        }
        if (number >= 4){
            return "IV" + convertToRoman(number - 4);
        }
        if (number >= 1){
            return "I" + convertToRoman(number - 1);
        }
        return "";
    }
}
