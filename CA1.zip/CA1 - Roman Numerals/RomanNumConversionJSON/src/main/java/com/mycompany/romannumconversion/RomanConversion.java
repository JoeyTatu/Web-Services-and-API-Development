/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.romannumconversion;

/**
 * @file: RomanConversion.java
 * @created: 17 October 2018
 * @modified: 19 October 2019
 * @author: Keith Feeney - x15015556@student.ncirl.ie
 */

//@reference: moodle.ncirl.ie (moodle2018.ncirl.ie) - Web Services & API - "Tutorial - Jersey" - https://moodle.ncirl.ie/pluginfile.php/174649/mod_resource/content/0/Tutorial%20-%20Jersey.pdf
//@reference: moodle.ncirl.ie (moodle2018.ncirl.ie) - Web Services & API - "Tutorial - Jersey Client" - https://moodle.ncirl.ie/pluginfile.php/174658/mod_resource/content/0/Tutorial%20-%20Jersey%20Clients.pdf
//@editedby: Keith Feeney

import com.google.gson.Gson;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@Path("/tools") // localhost:8080/tools gets RomanConversion{...}
public class RomanConversion {

    @GET
    @Path("/convertToRoman") // localhost:8080/tools/convertToRoman // gets getRomanrNums(...)
    @Produces("application/json") //@Produces("text/html; charset=UTF-8")
    public Response getRomanNums(@Context UriInfo info){
        Gson gson = new Gson();
        
        String toRomanInput = info.getQueryParameters().getFirst("toRoman");//gets the input from the index.html page

        ConvertToRoman romanConverted = new ConvertToRoman(Integer.parseInt(toRomanInput)); //creates and uses the ConvertToRoman class, result is a string, so this converts it to an integer.

       return Response.status(200).entity(gson.toJson(romanConverted)).build(); //set response to 200 (OK), covert gson to json with romanConverted and build the page.
    }
    
    @GET
    @Path("/convertToInteger") // localhost:8080/tools/convertToInteger // gets getIntegerNums(...)
    @Produces("application/json") //@Produces("text/html; charset=UTF-8")
    public Response getIntegerNums(@Context UriInfo info){
        Gson gson = new Gson();
        
	String toIntegerInput = info.getQueryParameters().getFirst("toInteger"); //gets the input from the index.html page

        ConvertToInteger integerConverted = new ConvertToInteger(toIntegerInput); //creates and uses the ConvertToInteger class

       return Response.status(200).entity(gson.toJson(integerConverted)).build(); //set response to 200 (OK), covert gson to json with integerConverted and build the page.
    }
    
    @POST
    @Path("/echo")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response post(String entity){
       return Response.status(200).entity(entity).build();
    }

}

