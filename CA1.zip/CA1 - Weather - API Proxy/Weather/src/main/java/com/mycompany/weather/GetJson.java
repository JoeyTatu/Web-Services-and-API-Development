/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.weather;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
 * @file: GetJson.java
 * @created: 18 October 2018
 * @modified: 19 October 2019
 * @author: Keith Feeney - x15015556@student.ncirl.ie
 */
public class GetJson{
    String jsonReply;
    //String city;
    
    public String getJson(String city) throws MalformedURLException, IOException{ // if URL is not valid, throws a MalformedURLException. If cannot open connection, throws an IOException.
        //@reference: https://dzone.com/articles/how-to-parse-json-data-from-a-rest-api-using-simpl
        //@editedby: Keith Feeney
        String mode = "json";
        String appid = "a9420298640ce7d382a4a523a5f20a11"; //API Key
        //Decided to use these String variables for good practice. If app was larger, would be easier to change the mode and API key
        
        URL url = new URL("http://api.openweathermap.org/data/2.5/forecast?q="+ city + "&mode=" + mode + "&appid=" + appid);
        
        HttpURLConnection conn = (HttpURLConnection)url.openConnection(); //opens the connection
        conn.setRequestMethod("GET"); //method is set to "GET"
        conn.connect(); //connection starts
        
        int responseCode = conn.getResponseCode();
        
        if(responseCode != 200){
            throw new RuntimeException("HttpResponseCode: " + responseCode); //if an error occures with connecting, it throws a RuntimeException. 
        }
        else{
            Scanner sc = new Scanner(url.openStream()); //scanner is set to the open connection.
            while(sc.hasNext()){ //while there is data
                jsonReply = jsonReply + sc.nextLine(); //add to jsonReply
            }
            sc.close();
        }
        
        return jsonReply;
    }
    
}
