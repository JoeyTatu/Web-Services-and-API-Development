/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.weather;

/**
 * @file: OpenWeather.java
 * @created: 18 October 2018
 * @modified: 19 October 2019
 * @author: Keith Feeney - x15015556@student.ncirl.ie
 */

//@reference: moodle.ncirl.ie (moodle2018.ncirl.ie) - Web Services & API - "Tutorial - Jersey" - https://moodle.ncirl.ie/pluginfile.php/174649/mod_resource/content/0/Tutorial%20-%20Jersey.pdf
//@reference: moodle.ncirl.ie (moodle2018.ncirl.ie) - Web Services & API - "Tutorial - Jersey Client" - https://moodle.ncirl.ie/pluginfile.php/174658/mod_resource/content/0/Tutorial%20-%20Jersey%20Clients.pdf
//@editedby: Keith Feeney

import com.google.gson.Gson;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import com.sun.jersey.api.client.ClientResponse;
import java.io.IOException;
import java.net.MalformedURLException;



@Path("/main")
public class OpenWeather {
    
    Gson gson = new Gson();
    
    @GET
    @Path("/getWeather")
    @Produces("text/html; charset=UTF-8")
    public Response getWeather(@Context UriInfo info) throws MalformedURLException, IOException{
        
        
        String city = info.getQueryParameters().getFirst("city");
        // Gson g = new Gson();
        GetJson j= new GetJson(); //declaring a new class of GetJson
        String jsonReply = j.getJson(city);//assigning ang getting jsonReply. 
        
        ////////// trying to see would this work. I presume it's because this is more for one's own server, not connecting to a server. /////////////
        //        String mode = "json";
        //        String appid = "a9420298640ce7d382a4a523a5f20a11";
        //        
        //        String getUrl = "http://api.openweathermap.org/data/2.5/forecast";
        //        
        //        Client client = Client.create();
        //        WebResource target = client.resource(getUrl);
        //
        //        ClientResponse response = target
        //                .queryParam("q", city)
        //                .queryParam("mode", mode)
        //                .queryParam("appid", appid)
        //                .get(ClientResponse.class); 
        //       
        // return Response.status(200).entity((JsonReply)).build();
//        System.out.println(jsonReply); //testing
//        ClientResponse convertedToJson = gson.fromJson(jsonReply, ClientResponse.class); //was trying to convert it from gson to json. 
//        System.out.println(convertedToJson); //testing

        return Response.status(200).entity((jsonReply)).build(); //returns a 200 response (OK response) with the jsonReply file, and builds the page.

    }
    @POST
    @Path("/echo")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response post(String entity){
       return Response.status(200).entity(entity).build();
    }

}

