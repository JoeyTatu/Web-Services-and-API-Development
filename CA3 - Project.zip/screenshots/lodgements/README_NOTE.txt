Didn't do screenshots of Withdrawals and BankTransfer as they are very similar to Lodgements.

The video shows them all.